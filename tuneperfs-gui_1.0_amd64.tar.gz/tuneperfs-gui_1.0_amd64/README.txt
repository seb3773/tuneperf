TunePerf GUI - Trinity Desktop Environment (TDE) Build
Version: 1.0
Architecture: amd64

This is the dynamically linked version of the TunePerf GUI.
It requires a functioning Trinity Desktop Environment (TDE) and TQt3 packages installed on the system.

Usage:
  ./tuneperfs-gui

Note:
  Do not run this binary with 'sudo' or as root. The GUI runs in your user session
  and will securely prompt for administrative credentials when performing backend changes.
