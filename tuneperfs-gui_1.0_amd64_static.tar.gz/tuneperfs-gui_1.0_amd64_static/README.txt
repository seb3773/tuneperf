TunePerf GUI - Standalone Static Build
Version: 1.0
Architecture: amd64

This is the statically linked standalone version of the TunePerf GUI.
It embeds TQt3 and has no Trinity Desktop (TDE) dependencies. It runs on any
Linux system with standard graphics server libraries (X11, fontconfig, freetype).

Usage:
  ./tuneperfs-gui

Note:
  Do not run this binary with 'sudo' or as root. The GUI runs in your user session
  and will securely prompt for administrative credentials when performing backend changes.
